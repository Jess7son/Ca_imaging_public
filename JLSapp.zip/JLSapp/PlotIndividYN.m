function [] = PlotIndividYN(somaticF_DF,SigParams,i,activeYN,FiltSig)

%use later to cap graps in y-direction
meanmax = mean(max(somaticF_DF));
meanmin = mean(min(somaticF_DF));

%can't plot NaNs, so we've got another matrix just for plotting
%purposes
tlocs = SigParams.troths(2,:); 
pks = SigParams.peaks(1,:);
locs = SigParams.peaks(2,:);
%         meanvalue = mean(pks);

%plot each cell trace with peaks as red'*' and troths as blue'o'
for q=1:size(FiltSig,1)
    %plot unfiltered signal in the background
    plot(somaticF_DF(i,:),'Color',[.8 .8 .8]); 
    hold on;
    ylim([meanmin meanmax]);
    %now plot the filtered signal
    plot(FiltSig,'k')
    if ~isnan(pks)
        plot(locs, pks,'r*')
        plot(tlocs,FiltSig(tlocs),'bo');
%                 MeanLine = line([0,length(FiltSig)],[meanvalue, meanvalue]);
        MeanLine.Color = 'black';
        MeanLine.LineWidth = 1;
        MeanLine.LineStyle = '--';
        MeanLine;
%                 text(5, meanvalue+(meanvalue/30), 'Mean of Peaks');
        annotation('textbox',[.8 .8 .1 .1],'String',['Cell # ' num2str(i)],'EdgeColor','none')
    end
    if activeYN(i)>0
        a = annotation('textbox',[.8 .7 .1 .1],'String',['ACTIVE'],'EdgeColor','none');
        a.Color = 'blue';
        a.FontSize = 16;
    else
        a = annotation('textbox',[.8 .7 .1 .1],'String',['INACTIVE'],'EdgeColor','none');
        a.Color = 'red';
        a.FontSize = 16;
    end
    hold off;
end