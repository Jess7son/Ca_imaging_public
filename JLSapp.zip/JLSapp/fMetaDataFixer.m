function [] = fMetaDataFixer(app)
   
    load(app.CurrFile);
    
    %% This app takes user input
    
    if ~isfield(fMetaData,'Date');
        Date = input('\n What date was this video taken?(YYMMDD)');
        fMetaData.Date = Date;
    end
    
    if ~isfield(fMetaData,'Researcher');
        Researcher = input('\n What are the initials of the collecting researcher?');
        fMetaData.numsecs = Researcher;
    end
    
    if ~isfield(fMetaData,'Species');
        Species = input('\n What Species are these data? (Ms = mouse / Rt = rat / Hu = human)');
        fMetaData.numsecs = Species;
    end    
    
    if ~isfield(fMetaData,'Size');
        Size = input('\n What size was this sphere? (2K / 4K / 8K)');
        fMetaData.numsecs = Size;
    end
    
    if ~isfield(fMetaData,'Sex');
        Sex = input('\n What sex was this sphere? ( M / F / X )');
        fMetaData.numsecs = Sex;
        
    end
    
    if ~isfield(fMetaData,'Days_In_Vitro');
        div = input('\n How many DIV was this sphere?');
        fMetaData.numsecs = div;
    end
    
    if ~isfield(fMetaData,'Sphere_Number');
        snum = input('\n What number was this sphere?');
        fMetaData.numsecs = snum;
    end
    
    if ~isfield(fMetaData,'width');
        fMetaData.width = [];
        fMetaData.height = [];
    end
    
    if ~isfield(fMetaData,'Condition')
        fMetaData.Condition = 'CTL';
    end
    
    if ~isfield(fMetaData,'numsecs')
        numsecs = input('\n How long was this recording? (in seconds)');
        fMetaData.numsecs = str2num(numsecs);
    end
    
    if ~isfield(fMetaData,'frames')
        fMetaData.frames = size(somaticF_DF,2);
    end
    
    if ~isfield(fMetaData,'name')
       fMetaData.name = CurrFile;
    end
    
    %% Place in proper order
    B = {'Date','Researcher','Species','Size','Sex','Days_In_Vitro', ...
        'Sphere_Number','Condition','width','height','frames','numsecs','name'};
    fMetaData = orderfields(fMetaData,B);

    save(CurrFile, 'fMetaData', '-append');
    
    fprintf('Success!')
    
end
