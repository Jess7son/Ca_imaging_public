function [CellParams,SphereParams] = SigParamCalc(app)
% FreqOfInt,cutoff,plotyn, pausesec)


% % fprintf('For each cell, please press left mouse (active), right mouse (NOT active), or B(back)\n');
    % FreqOfInt: frequency band where activity is expected. should be 2-element
    % vector ex: [0.15 2] that is BETWEEN 0.05 and the nyqist frequency
    % cutoff: stringency requirement for HOW powerful activity has to be to be 'active'
    % plotyn: determines whether you want the individual spheroid plots. 1
    % is yes, 0 is no
    % pausesec: number of seconds to pause on each chart
    
%% Pass in variables
    somaticF_DF = app.somaticF_DF;
    fMetaData = app.fMetaData;
    %other somatic?
    FreqOfInt = app.FreqOfInt; %pass in from app
    cutoff = app.cutoff;%pass in from app
    groupsyn = app.GroupPlotsCheckBox.Value; %pass in from app
    individyn = app.IndividPlotsCheckBox.Value;
%     pausesec = app.pausesec; %pass in from app
    
%% Declare Variables that do not change 
    %for frequency calculations later
    sigThres=.01; %threshold of signal
    params.pad=0; %padding 
    params.tapers= [2 3]; %[3 5]; %number of tapers (?)
    params.trialave = 1; %do we trial average? 1 is yes.
    params.err = [1 sigThres]; %error
    
    %properties of Savitzky-Golay (polynomial order and witdth)    
    rd = 9; %Polynomial order for SG-filter = 9
    fl = 51; %51 frames for SG-Filter (Must be odd)
    
    clf;

    FPS = fMetaData.frames / fMetaData.numsecs;
    gauss = FPS/2; %1/2 second gaussian filter

    
    if FreqOfInt(1) < 0.05 || FreqOfInt(2) > FPS/2
        error(['ERROR: Desired frequencies are outside the bounds of recording.' ...
            ' Please select a frequency range between 0.05 and FPS/2'])
    end
    
    params.Fs= FPS; %sampling frequency (frames per second)
    nyquist = round(FPS/2);
    params.bandpass = [0.05 nyquist]; %0.05 to get rid of low freq noise, then nyquist frequency


    %% To Get Frequency (per whole sphere)
    numneurons = size(somaticF_DF,1)-2;
    chan = 1:numneurons; % select channels to include
    % NOTE: you can also look at individual channels, but
    %%this doesn't work as well (noisy) so I don't use it.

    %uses Cronux toolbox to extract frequency spectrum
    [SP,fP,~]= mtspectrumc(somaticF_DF(chan,:)', params); 
    
    %finds all peaks, then keeps only the most prominent (mean + 2*st.dev)
    [~,~,~,p]=findpeaks(SP);
     p = mean(p)+std(p);
    [~,peakLocs,~,~]=findpeaks(SP,'sortstr','descend','MinPeakProminence',p);

    %exports corresponding frequencies as part of the output structure
    SphereParams.freq = fP(peakLocs);

    %% Data Filtration Loop
    %This is to smooth the data before it gets analyzed. Layered filters
    %are a Savitzky-Golay Filter, then a median filter (remove any outliers) 
    %then a gaussian. The median filter has a width of 1/2 what the 
    %gaussian is set to, to prevent signal loss.
    
    FiltSigAll = zeros(size(somaticF_DF,1)-2,size(somaticF_DF,2));
    for j = 1:numneurons
         FiltSigAll(j,:) = sgolayfilt(somaticF_DF(j,:),rd,fl);
         FiltSigAll(j,:) = smoothdata(FiltSigAll(j,:),'movmedian',gauss/2);
         FiltSigAll(j,:) = smoothdata(FiltSigAll(j,:),'gaussian',gauss);
    end
        %create Correlation Matrix to observe how each cell is correlated with
        %each other cell (so we can pull individual rows from this later)
        corr_matrix = corrcoef(FiltSigAll');

        %% Individual CELL Loop (by row within a file)
        ActiveCoeff = zeros(1,numneurons);
        activeYN = zeros(1,numneurons);
        
        for i=1:(size(FiltSigAll,1))

            %Bring up JUST the row of FiltSig we need
            FiltSig = FiltSigAll(i,:);

            %Calls CaDynAnlys Funcyion, which extracts Signal Parameters for
            %each cell, then assigns them to a row in a larger structure.
            [TempCellParams] = getCellParams(FiltSig, FPS, corr_matrix, i, SphereParams);
            CellParams(i,:) = TempCellParams;
    
            %% Spectrum Analysis
            %calculates the ratio of power at (FrequencyOfInterest) Hz vs the
            %power on the whole spectrum. If the ratio is higher than (Cutoff),
            %the cell is declared 'active'.
            
            %create matrix of powers at (0.05 - nyquist)
            [SPi,fPi,~]= mtspectrumc(somaticF_DF(i,:)', params);
            %find the values that for the range of expected activity
            SPiRange = SPi(find(fPi>FreqOfInt(1),1,'first'):find(fPi<FreqOfInt(2),1,'last'));
%             %find the power in the desired range
%             SPactive = sum(SPiRange)/length(SPiRange);
%             %find normalized power (if it were evenly distributed) 
%             SPall = (sum(SPi)/length(SPi)); 
            %get the ratio of these two numbers
            ActiveCoeff(i) = sum(SPiRange)/sum(SPi);
                        
            %if the ratio is high enough (I use >1.2), the cell is active
            if ActiveCoeff(i)>cutoff
                activeYN(i) = 1;
            end
            
            if individyn == 1
                %OPTIONAL: Sanity check for variance of a signal
                totcellvar(i) = var(somaticF_DF(i,:),[],2); %find total variance in the signal of that cell

    %           OPTIONAL: plotting function for individual cells to see if you agree with the
    %           activeYN calls the program is making
                PlotIndividYN(somaticF_DF,TempCellParams,i,activeYN,FiltSig);
                pause(0.5);
                clf;
            
            end
        end
    
    %% Now get Whole Sphere Parameters -
    % Amplitude, Rise, Decay_50, and % Active (have data for each cell)
    Amps = nan(1,numneurons); Rise = nan(1,numneurons); Decay50 = nan(1,numneurons);
    quiescCorr = nan(1,numneurons); activeCorr = nan(1,numneurons);
    %creates matrix just for the 'active' cells.
    actmatrix = zeros(sum(activeYN),fMetaData.frames);
    quiescmatrix = zeros(length(activeYN)-sum(activeYN),fMetaData.frames);
    n = 0; o = 0; %these are counters needed for the next loop
    
    for m = 1:numneurons     
        if activeYN(m)>0
            %correlate ONLY active cells to other active cells
            n = n+1;
            actmatrix(n,:) = FiltSigAll(m,:);
            corr_actmatrix = corrcoef(actmatrix');
            %mean value at which active cells are correlated TO EACH OTHER ONLY
            %this is important so that lots of inactive cells don't drag
            %your correlation value down
            corr_actmatrix(n,n) = NaN;
            activeCorr(n) = mean(corr_actmatrix(n,:),'omitnan'); 
            %now import values from CaDynAn
            Amps(m) = CellParams(m).amps(1); %mean amplitude of detected activity
            StdAmps(m) = CellParams(m).amps(2);%stdev, currently unused
            Rise(m) = CellParams(m).rise(1); %mean rise time of detected activity
            StdRise(m) = CellParams(m).rise(2); %stdev, currently unused
            Decay50(m) = CellParams(m).decay50(1); %mean Tau-50 of detected activity
            StdDecay50(m) = CellParams(m).decay50(2); %stdev, currently unused
            CellParams(m).activeYN = 1; %so you can check on this later
        else
            % %Correlates inactive cells with all other cells, bc why not
            CellParams(m).activeYN = 0;
            o = o+1;
            quiescmatrix(o,:) = FiltSigAll(m,:);
            corr_quiescmatrix = corrcoef(quiescmatrix');
            %mean value at which quiescent cells are correlated TO OTHER quiescent cells ONLY
            corr_quiescmatrix(o,o) = NaN;
            quiescCorr(o) = mean(quiescmatrix(o,:),'omitnan'); 
        end
    end
   
%    %%OPTIONAL: Plot your correlation matrices
%     h = heatmap(corr_actmatrix); %plot as heatmap
%     h.Colormap = jet; %sets colorscheme

%   Get percent active
    PercAct = round(sum(activeYN)/length(activeYN) * 100);
    if PercAct == 0
        SphereParams.freq = NaN;
    end
    
    %fill the structures of sphereparams
    SphereParams.amp = mean(Amps(1,:),'omitnan');
    SphereParams.rise = mean(Rise(1,:),'omitnan');
    SphereParams.decay50 = mean(Decay50(1,:),'omitnan');
    SphereParams.percAct = round(sum(activeYN)/length(activeYN) * 100);
    SphereParams.activeCorr = mean(activeCorr,'omitnan');
    SphereParams.inactiveCorr = mean(quiescCorr(1,:),'omitnan');
    
    %Plot the active and inactive cells for every sphere (to ensure correct
    %cell thresholding)
    if groupsyn == 1
        clf;
        subplot(2,1,1); plot(actmatrix'); ylabel =('Active Cells');
        subplot(2,1,2); plot(quiescmatrix'); ylabel=('Quiescent Cells');
%         pause(pausesec);
    end
    
    %make sure structure is in same order (important for table)
    C = {'amp','rise','decay50','percAct','activeCorr','inactiveCorr','freq'};
    SphereParams = orderfields(SphereParams,C);
    
    %% Save Variables
    %Saves the specified parameters to a structure - fSigParams - within a
%     %file.
%     
% %     fprintf(['\n' num2str(k)]);
%      save([Files(k).folder '/' Files(k).name(1:end-4)], 'SphereParams', ...
%          'fSigParams', 'fMetaData','somatic*','-append');
%     
%     %clean up after yourself
%     clear a* A* bk* bo* C* ch* d* D* e* Filt* Fra* FreqC* g* h* i* j* l* m* ...
%         n* o* pe* Pe* q* R* S* so* SP* sROIs* Std* t* T* u* v* w* x* y* z* ...
%          Sp* fMeta* corr* p fP* FPS Freq fSig* sec* chan* som* Sphere*
 