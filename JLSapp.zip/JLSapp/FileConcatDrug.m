function [] = FileConcatDrug(app)
%% program for the manual concatonation of somatic variables in 2 calcium videos

ctlFile = app.ccFile1; %name first file
load(ctlFile,'somatic*','fMetaData');

cnd1File = app.ccFile2; %name 2nd file

newFile = [ctlFile(1:end-4) '_' app.NewName '.mat']; %name output file
cond1 = [fMetaData.Condition '-' num2str(fMetaData.frames) '_'];

%% Rename variables to control condition


%ctlSomaticBL = somaticBL;
ctlSomaticF = somaticF;
%ctlSomaticF_BLCutOffs = somaticF_BLCutOffs;
ctlSomaticF_DF = somaticF_DF;
ctlSomaticF_nonBL = somaticF_nonBL;
ctlSomaticROI_PixelLists = somaticROI_PixelLists;
ctlSomaticROIBoundaries = somaticROIBoundaries;
ctlSomaticROICenters = somaticROICenters;
ctlSomaticROIs = somaticROIs;
ctlSomaticROICounter = somaticRoiCounter;
frames = fMetaData.frames;
numsecs = fMetaData.numsecs;

clear somatic* fMeta*;

%% Load in second variables and rename them

load(cnd1File,'somatic*','fMetaData');
if ctlSomaticROICounter ~= somaticRoiCounter
    error(['ERROR! Please double-check your ROIs; there is a mismatch ' ...
        'between these files. They seem to have a different number of cells.'])
end
    
    
%cnd1SomaticBL = somaticBL;
cnd1SomaticF = somaticF;
%cnd1SomaticF_BLCutOffs = somaticF_BLCutOffs;
cnd1SomaticF_DF = somaticF_DF;
cnd1SomaticF_nonBL = somaticF_nonBL;
cnd1SomaticROI_PixelLists = somaticROI_PixelLists;
cnd1SomaticROIBoundaries = somaticROIBoundaries;
cnd1SomaticROICenters = somaticROICenters;
cnd1SomaticROIs = somaticROIs;
frames = frames + fMetaData.frames;
numsecs = numsecs + fMetaData.numsecs;
cond2 = [fMetaData.Condition '-' num2str(frames)];
clear somatic*;

%% Create Concatonated Variables

%somaticBL = [ctlSomaticBL cnd1SomaticBL];
somaticF = [ctlSomaticF cnd1SomaticF];
%somaticF_BLCutOffs = [ctlSomaticF_BLCutOffs; cnd1SomaticF_BLCutOffs];
somaticF_DF = [ctlSomaticF_DF cnd1SomaticF_DF];
somaticF_nonBL = [ctlSomaticF_nonBL cnd1SomaticF_nonBL];
somaticROI_PixelLists = [ctlSomaticROI_PixelLists; cnd1SomaticROI_PixelLists];
somaticROIBoundaries =[ctlSomaticROIBoundaries; cnd1SomaticROIBoundaries];
somaticROICenters = [ctlSomaticROICenters; cnd1SomaticROICenters];
somaticROIs = [ctlSomaticROIs; cnd1SomaticROIs];
somaticRoiCounter = ctlSomaticROICounter;

newCondition = [cond1 cond2];
fMetaData.frames = frames;
fMetaData.numsecs = numsecs;
fMetaData.Condition = newCondition;
% fMetaData.name = newFile;

clear cnd1* ctl* frames* numsecs* newCondition;
%% Save resultant variables to an output file
save(newFile, 'somatic*', 'fMetaData');
fprintf('Success! (probably) \n Please check the folder in which you keep File #1 \n')
