function [] = PowerSpectrumCalc(app)
% FilePath = ('C:\Users\jess7\Documents\Grad_School\DHK_Labtime\ConfocalImages\180927-F-D10-rep2-NBQX_unf\Sphere02\');
% FileName = ('180927_JLS_Rt_8K_F_DIV09_cndFULL_SN02.mat');
% load([FilePath FileName]);

if isempty(app.CellsOfInt)
    app.CellsOfInt = app.somaticF_DF(1:end-2,:);
end
datamat = app.CellsOfInt;
numneurons = size(datamat,1);
BP1 = app.LowEditField.Value;
BP2 = app.HighEditField.Value;
fMetaData = app.fMetaData;

FPS = fMetaData.frames/fMetaData.numsecs;
bandpass = [BP1 BP2]; % [fqBandpass(1) fqBandpass(2) ];
gauss = FPS/2;
%power spectrum

%% Don't touch below here

sigThres=.01; %threshold of signal
params.pad=0; %padding 
params.Fs= FPS; %sampling frequency (frames per second)
params.tapers= [2 3]; %[3 5]; %number of tapers (?)
params.trialave = 1; %do we trial average? 1 is yes.
params.err = [1 sigThres]; %error

params.fpass= bandpass;

FiltSig = smoothdata(datamat(1:numneurons,:),2,'gaussian',gauss);

chan = [1:numneurons];   % select channels to include
% chan = [ 1 ]; % NOTE: you can also look at individual channels

figure('Renderer', 'painters', 'Position', [10 50 700 350]);

%% Spectrum Analysis
[SP,fP,errP]= mtspectrumc(datamat(chan,:)', params); 

if app.Show95CICheckBox.Value == 1
    SpectrumPlot(SP,fP,'l',errP,'b',[2 1]); %from Chronux
else
    SpectrumPlot_NoErr(SP, fP, 'l', 'b',1); %modified from Chronux
end
%plot_spectrum(SP, fP, errP, 'l', 'b', [2 1]);

ylabel('Power Spec. Dens.');
xlabel('frequency(Hz)');
title(['Power Spectrum: ' app.AnalyzeDropDown.Value]);
set(gca,'fontsize', 14);

fPmain = find(SP>=max(SP));
Freq = fP(fPmain);
% plot(fP(fPmain),10*log10(SP(fPmain)),'r.', 'markersize', 15);
annotation('textbox',[.75 .35 .2 .1],'String',['Freq = ' num2str(Freq)],'EdgeColor','none')

