function [] = MultiRainbowDrug(app)

datamat = app.somaticF_DF;
numneurons = size(datamat,1)-2;
fMetaData = app.fMetaData;
timebreak = zeros(1,3);
condnames = cell(1,3);

FPS = fMetaData.frames/fMetaData.numsecs;
Frames = fMetaData.frames; %usually 1500 or 3000
TimeVals = (FPS:FPS:Frames)/FPS; %getting seconds from frames
FrameVals = FPS:FPS:Frames; %For plotting
inc = app.XincrementsEditField.Value; %increment for tic marks in X axis
chan = [1:numneurons];   % select channels to include

    numcond = 1;
    timebreak(1)= app.EditField_1.Value * FPS;
    condnames{1} = app.Treatment1EditField.Value;

if ~isempty(app.Treatment2EditField.Value)
    numcond = 2;
    timebreak(2)= app.EditField_2.Value * FPS;
    condnames{2} = app.Treatment2EditField.Value;
    if timebreak(2) == 0
        error('Please Enter the Time in Seconds at which Treatment 2 was Initiated');
    end
end

if ~isempty(app.Treatment3EditField.Value)
    numcond = 3;
    timebreak(3)= app.EditField_3.Value * FPS;
    condnames{3} = app.Treatment3EditField.Value;
    if timebreak(3) == 0
        error('Please Enter the Time in Seconds at which Treatment 3 was Initiated');
    end
end


%% Now the figure

%first plot your controls
figure;
subplot(numcond+1,1,1);
imagesc(datamat(chan,1:timebreak(1)-1)); colormap jet;
blue2yellow = caxis;
set(gca,'fontsize', 14);
ax=gca; 
ax.XTick = [FrameVals(inc:inc:end)]; ax.XTickLabel = [TimeVals(inc:inc:end)];
title('Control');
xlabel('time(sec)'); ylabel('Cell #'); colorbar;

%Now do your conditions
for i = 1:numcond
    subplot(numcond+1,1,i+1);
    %figure out which timepoints you need
    if i == numcond
        seriesb = timebreak(i):size(datamat,2);
    else
        seriesb = timebreak(i):timebreak(i+1)-1;
    end
    
    imagesc(datamat(chan,seriesb),blue2yellow);
    
     %label X and Y axes for this plot
    set(gca,'fontsize', 14);
    ax=gca; 
    ax.XTick = [FrameVals(inc:inc:end)]; ax.XTickLabel = [TimeVals(inc:inc:end)];
    xlabel('time(sec)'); ylabel('Cell #'); colorbar;
    title(condnames{i});
end