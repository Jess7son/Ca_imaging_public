function [CellParams] = getCellParams(FiltSig, FPS, corr_matrix, i, SphereParams)
%UNTITLED Summary of this function goes here
    
    %This is to locate ALL the peaks in the data. It returns:
    %pks = peak heights, locs = peak locations, w = peak width, p = peak
    %prominence.
    [~,~,w,p] = findpeaks(FiltSig);
    %Now eliminate unimportant peaks: must have prominence>mean prom
    % and width @ 1/2 of resonant frequency.
    p = mean(p);
    
    highestF = max(SphereParams.freq);
    if FPS/highestF < FPS/2
        targwidth = FPS/highestF; %width should be the 
        %maximum prominent frequency of the sphere
    else
        targwidth = FPS/2;
    end

    [pks,locs,~,~] = findpeaks(FiltSig,'MinPeakProminence',p,'MinPeakWidth',targwidth);
    
    %Now we invert the signal and do the same thing to look for troths.
    TrothFinder = -FiltSig;
    [~,~,~,tp] = findpeaks(TrothFinder);
    %Now eliminate unimportant troths: must have prominence>mean prominence
    %and 1/4 sec width
    tp = mean(tp);
    [trths,tlocs,~,~] = findpeaks(TrothFinder,'MinPeakProminence',tp,'MinPeakWidth',targwidth);
    
    %data cleaning loop. Use to "line up" each peak with the troth directly
    %before it. The second clause is a "while" loop to check for multiple
    %inidences of troths in a row
    
    if numel(locs)>0 && numel(tlocs)>0
     % B = 1 is a special case that the next loop won't handle well, so 
     %this is a special check for it
        while locs(1)<tlocs(1)
                locs(1) = [];
                pks(1) = [];
        end

        if tlocs(2)<locs(1)
            tlocs(2)=[];
            trths(2)=[];
        end

        %this is the main loop
        for b =1:length(pks)
            %if two peaks come before the next troth, keep only the second
            %peak
            c = b;
            while c<=numel(locs) && b<=numel(tlocs) && locs(c)<tlocs(b) 
                locs(c) = [];
                pks(c) = [];
            end
            %if there are multiple troths before the next peak, only look at the last one
            d = b;
            while (d+1)<=numel(tlocs) && b<=numel(locs) && tlocs(d+1)<locs(b) 
                tlocs(d) = [];
                trths(d) = [];
            end
        end
        
        %Now find Inter-peak intervals (IPIs)
        ipi = [];
        for b=1:length(pks)-1
            ipi(b) = locs(b+1)-locs(b);
        end
        
        ipimode = mode(ipi);
        ipimean = mean(ipi);
        ipivar = std(ipi);

%     %get a mean value of the peaks (sanity check)
%     meanvalue = mean(pks);
    

    %For each peak, print out the HEIGHT between it and the closest previous troth
    %if previous trothis NaN, skip it

        %print out how long it takes to get halfway back to the troth value
        %preallocate Amplitude, Rise Time, and Decay Time (50%) as NaN matrices
        amplitude = nan([size(pks,1),size(pks,2)]);
        risetime = nan([size(pks,1),size(pks,2)]);
        decaytime50 = nan([size(pks,1),size(pks,2)]);
        %decaytime(1) = first place between locs(b) and locs(b+1) where FiltSig

        for b=1:length(pks)
            if length(trths)<b
                break
            else
            amplitude(b) = (pks(b) - trths(b));
            risetime(b) = (locs(b)-tlocs(b))/FPS; 
                if b+1<=numel(locs) %the final decay time will be NaN
                        T50 = pks(b)-(amplitude(b)/2);
                        ipi = FiltSig(locs(b):locs(b+1));
                            if sum(ipi<T50)>0
                                decay =  find(ipi<T50,1);
                                decaytime50(b) = decay/FPS;
                            end
                end
            end
        end
    
    %if you cant detect any peaks, set everything to NaN.
    else
        pks = NaN; locs = NaN; trths = NaN; tlocs = NaN;
        amplitude = NaN;
        risetime = NaN;
        decaytime50 = NaN;
        ipimean = NaN;
        ipimode = NaN;
        ipivar = NaN;
    end
    
%can still get mean correlation either way
meanCorr = mean(corr_matrix(i,:));

CellParams.peaks = [pks; locs];
CellParams.troths = [trths; tlocs];
CellParams.ipi = [ipimode ipimean ipivar];
CellParams.amps = [mean(amplitude, 'omitnan') std(amplitude, 'omitnan')];
CellParams.rise = [mean(risetime, 'omitnan') std(risetime, 'omitnan')];
CellParams.decay50 = [mean(decaytime50, 'omitnan') std(decaytime50, 'omitnan')];
CellParams.corr = [meanCorr];
CellParams.activeYN = [];

end

