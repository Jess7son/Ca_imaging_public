function [] = SSIMSdrug(app)

datamat = app.somaticF_DF;
numneurons = size(datamat,1)-2;
fMetaData = app.fMetaData;
timebreak = zeros(1,3);
condnames = cell(1,3);
ntrials = fMetaData.numsecs/6; %number you're going to cut the time up by


FPS = fMetaData.frames/fMetaData.numsecs;
Frames = fMetaData.frames; %usually 1500 or 3000
TimeVals = (FPS:FPS:Frames)/FPS; %getting seconds from frames
FrameVals = FPS:FPS:Frames; %For plotting
inc = app.XincrementsEditField.Value; %increment for tic marks in X axis
chan = [1:numneurons];   % select channels to include

%% Create Variables Based on # of conditions
    numcond = 1;
    timebreak(1)= app.EditField_1.Value * FPS;
    condnames{1} = app.Treatment1EditField.Value;
    seriesa = 1:timebreak(1)-1;
    seriesb = timebreak(1):size(datamat,2);
    seriesc = []; seriesd = []; %initialize time arrays

if ~isempty(app.Treatment2EditField.Value)
    numcond = 2;
    timebreak(2)= app.EditField_2.Value * FPS;
    condnames{2} = app.Treatment2EditField.Value;
    if timebreak(2) == 0
        error('Please Enter the Time in Seconds at which Treatment 2 was Initiated');
    end
        seriesb = timebreak(1):timebreak(2)-1;
        seriesc = timebreak(2):size(datamat,2);
end

if ~isempty(app.Treatment3EditField.Value)
    numcond = 3;
    timebreak(3)= app.EditField_3.Value * FPS;
    condnames{3} = app.Treatment3EditField.Value;
    if timebreak(3) == 0
        error('Please Enter the Time in Seconds at which Treatment 3 was Initiated');
    end
        seriesc = timebreak(2):timebreak(3)-1;
        seriesd = timebreak(3):size(datamat,2);
end


%% Standard Parameters

sigThres=.01; %threshold of signal
params.pad=0; %padding 
params.Fs= FPS; %sampling frequency (frames per second)
params.tapers= [2 3]; %[3 5]; %number of tapers (?)
params.trialave = 1; %do we trial average? 1 is yes.
params.err = [1 sigThres]; %error

bandpass = [0.05 FPS/2]; % [fqBandpass(1) fqBandpass(2) ];
params.fpass= bandpass;
%power spectrum

%% Initialize control data
seriesa = 1:timebreak(1);

%Preprocess data for use with CSIMS: CSmat = ( #events x #bins x #channels)
triallength = size(seriesa,2)/ntrials; % 100 = 4 sec?

LFPmat1 = zeros(ntrials,triallength,numneurons);
LFPmat2 = zeros(ntrials,triallength,numneurons);


%% CSIMS


dim = 3;
perp = 5;
metric = 'seuclidean'; % 'correlation' % 

chan =  [1:numneurons]; %22

if ~isempty(seriesd)
    LFPmat3 = zeros(ntrials,triallength,numneurons);
    LFPmat4 = zeros(ntrials,triallength,numneurons);
    for n = 1:numneurons
        win = [1:triallength] - triallength;
        for en = 1:ntrials
             win = win + triallength;
             LFPmat1(en,:,n) = [ datamat(n,win) ];
             LFPmat2(en,:,n) = [ datamat(n,win+min(seriesb)-1) ];
             LFPmat3(en,:,n) = [ datamat(n,win+min(seriesc)-1) ];
             LFPmat4(en,:,n) = [ datamat(n,win+min(seriesd)-1) ];
        end
    end
    [CSIMS_ENS, tSNE_transform, basedmat] = getCSIMS( [ LFPmat1(:,:,chan); LFPmat2(:,:,chan); LFPmat3(:,:,chan); LFPmat4(:,:,chan) ] , metric, dim, perp);
    id = [ zeros(1,ntrials) zeros(1,ntrials)+1 zeros(1,ntrials)+2 zeros(1,ntrials)+3];
elseif ~isempty(seriesc) 
    LFPmat3 = zeros(ntrials,triallength,numneurons);
    for n = 1:numneurons
    win = [1:triallength] - triallength;
        for en = 1:ntrials
             win = win + triallength;
             LFPmat1(en,:,n) = [ datamat(n,win) ];
             LFPmat2(en,:,n) = [ datamat(n,win+min(seriesb)-1) ];
             LFPmat3(en,:,n) = [ datamat(n,win+min(seriesc)-1) ];
        end
    end
    [CSIMS_ENS, tSNE_transform, basedmat] = getCSIMS( [LFPmat1(:,:,chan); LFPmat2(:,:,chan); LFPmat3(:,:,chan) ] , metric, dim, perp);   
    id = [ zeros(1,ntrials) zeros(1,ntrials)+1 zeros(1,ntrials)+2 ];
else
    for n = 1:numneurons
        win = [1:triallength] - triallength;
        for en = 1:ntrials
             win = win + triallength;
             LFPmat1(en,:,n) = [ datamat(n,win) ];
             LFPmat2(en,:,n) = [ datamat(n,win+min(seriesb)-1) ];
        end
    end
    [CSIMS_ENS, tSNE_transform, basedmat] = getCSIMS( [ LFPmat1(:,:,chan); LFPmat2(:,:,chan) ] , metric, dim, perp);
    id = [ zeros(1,ntrials)  zeros(1,ntrials)+1];
end


figure; 
colors = [[0 0 0.7]; [0.7 0 0]; [0 0 0]; [0 0.7 0]];
a = gca;
a.ColorOrder = colors; hold on;
plotNT(CSIMS_ENS, id,'symbol','.','msize',60,'avg_trajectories',0);

% title(['State space projection: baseline (blue) vs. ' drugz ' (red)']);

%% single neuron CSIMS
% 
% %n =  20  %10  %20
% 
% for n = 1:numneurons
% 
% % dim = 3
% % perp = 5
% % metric = 'seuclidean'
% 
% 
% [CSIMS, tSNE_transform, basedmat] = getCSIMS( [ LFPmat1(:,:,n); LFPmat2(:,:,n) ] , metric, dim, perp);
% 
% %figure
% %plotNT(CSIMS, id,'symbol','.','msize',80,'avg_trajectories',0);
% 
% 
% k = 1;
% kf = 5;
% 
% KNNClass = fitcknn(CSIMS, id,'NumNeighbors',k);
% CVKNN = crossval(KNNClass, 'kfold', kf);
% klossKNN =  (  kfoldLoss(CVKNN, 'mode', 'individual')  );
% pc  = 100*(1-klossKNN);
% pcM(n) = mean(pc);
% pcSD(n) = std(pc);
% 
% end
% %%
% 
% mciter = 1000; %number of monte carlo iterations to create the chance distr.
% for n = 1:mciter
%    idr = id(randperm(numel(id))); 
%    pcR(n) = 100* (numel( find(idr-id ==0)) / numel(id));
% end
% 
% %%
% 
% figure; %displays how good each channel is at separating the two conditions
% %some channels arent great (inactive) but others can distinguish really
% %easily. In case you want to put a number on how much each channel changes.
% 
% ed = 1:5:100; %edges of the bins we're using for the histogram
% 
% subplot(211)
% counts = histc(pcM,ed);
% counts = counts/numel(pcM);
% bar(ed,counts,'histc');
% 
% 
% title('single channel classification');
% subplot(212);
% counts = histc(pcR,ed);
% counts = counts/numel(pcR);
% bar(ed,counts,'histc');
% 
% title('chance')

