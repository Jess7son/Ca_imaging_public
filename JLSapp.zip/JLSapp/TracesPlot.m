function [] = TracesPlot(app)
%% Separates the traces for nice cells in a file

clear pickCells condition fMetaData somaticF_DF FPS gauss SB SBl SBh

pickCells = app.pickCells; %specify which cells you  want
condition = app.traceCondition; %if none leave blank
fMetaData = app.fMetaData;
somaticF_DF = app.somaticF_DF;
% 1/2/4/8 for 8K/DIV14/F #4 
% 1/2/3/7 for 8K/DIV10/F #4

FPS = fMetaData.frames/fMetaData.numsecs; %define Frames per second here
gauss = round(FPS/2); %gaussian filter by nyquist frequency
SB = (FPS*app.sbloc); %to place the scale bar
SBo = 0.3;
SBl = (FPS*app.sblength);
SBh = app.sbheight;

%quick data filtration to make viewing easier
FiltSig = smoothdata(somaticF_DF,2,'gaussian',gauss); 

%preallocate for speed
bestCells =zeros(length(pickCells),length(FiltSig));
j = 0; %counts rows in matrix
for i=pickCells
  j = j+1;
  bestCells(j,:) = FiltSig(i,:);
end

clf;
for i = 1:j  %separate them into subplots and plot
    subplot(j,1,i);
    plot(bestCells(i,:), 'k', 'LineWidth', 2); hold on;
    h = gca;
    h.YLim = [app.yMinEditField.Value app.yMaxEditField.Value];
    set(gca, 'visible', 'off');
    if ~isempty(condition)%If Drug
        for k = 1:length(condition)
            TP = condition(k)*FPS;
            line([TP TP],h.YLim,'color','r','LineWidth',5); 
        end
    end
end

% Creates scale bars in the first subplot
subplot(j,1,1);
 line([SB SB], [SBo SBo+SBh],'color','k', 'LineWidth',4) %0.1 dF/F scale bar
 line([SB SB+(SBl)], [SBo SBo],'color','k', 'LineWidth',4); %5-second scale bar

