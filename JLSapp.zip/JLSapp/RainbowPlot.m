function [] = RainbowPlot(app);
%% Declare Hardcoded Variables 
% not good coding practice, but here we are.
inc = app.XincrementsEditField.Value; %increment for tic marks in X axis
figTitle = ''; %DIV 14, Female #2 (0.1 Thresh)';
sortbymax = app.sbm_yn; %whether to sort the traces by max (1) or cell# (0)
somaticF_DF = app.somaticF_DF;
fMetaData = app.fMetaData;
%% subtract background & get Df/f

sROIs = size(somaticF_DF,1)-2; %last 2 ROIs arent cells (neuropil & BG)
%calculate the frequency of each cell
 bk_sub = [];

for i = 1:sROIs 
    bk_sub(i,:) = somaticF_DF(i,:);% - somaticF_DF(end,:);
end


Frames = fMetaData.frames; %usually 1500 or 3000
FPS = Frames/fMetaData.numsecs; %define Frames per second here
TimeVals = (FPS:FPS:Frames)/FPS; %getting seconds from frames
FrameVals = FPS:FPS:Frames; %For plotting
gauss = round(FPS/2);

%Now filter the signal with a gaussian filter of defined width
FiltSig = smoothdata(bk_sub,2,'gaussian',gauss);



%% plot 

figure('Renderer', 'painters', 'Position', [0 200 1275 400])
maxFS = max(FiltSig,[],2);
[~,index] = sort(maxFS,'descend');

SortedFS = FiltSig(index,:);

if sortbymax >0
    imagesc(SortedFS); colormap jet;
else
    imagesc(FiltSig); colormap jet;
end

ax=gca; 
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1) + .055;
bottom = outerpos(2) + ti(2) + .19;
ax_width = outerpos(3) - ti(1) - ti(3) - .07;
ax_height = outerpos(4) - ti(2) - ti(4) - 0.2;
ax.Position = [left bottom ax_width ax_height];

ax.XTick = [FrameVals(inc:inc:end)]; ax.XTickLabel = [TimeVals(inc:inc:end)];
ax.FontSize = 20;
xlabel('time(sec)'); ylabel('Cell #'); colorbar;
