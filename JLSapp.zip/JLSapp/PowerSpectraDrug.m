function [] = PowerSpectraDrug(app)
% FilePath = ('C:\Users\jess7\Documents\Grad_School\DHK_Labtime\ConfocalImages\180927-F-D10-rep2-NBQX_unf\Sphere02\');
% FileName = ('180927_JLS_Rt_8K_F_DIV09_cndFULL_SN02.mat');
% load([FilePath FileName]);
datamat = app.somaticF_DF;
numneurons = size(datamat,1)-2;
fMetaData = app.fMetaData;
timebreak = zeros(1,3);
condnames = cell(1,3);

FPS = fMetaData.frames/fMetaData.numsecs;
Frames = size(datamat,2); %usually 1500 or 3000
TimeVals = (FPS:FPS:Frames)/FPS; %getting seconds from frames
FrameVals = FPS:FPS:Frames; %For plotting
inc = app.XincrementsEditField.Value; %increment for tic marks in X axis
chan = [1:numneurons];   % select channels to include

    numcond = 1;
    timebreak(1)= app.EditField_1.Value * FPS;
    condnames{1} = app.Treatment1EditField.Value;

if ~isempty(app.Treatment2EditField.Value)
    numcond = 2;
    timebreak(2)= app.EditField_2.Value * FPS;
    condnames{2} = app.Treatment2EditField.Value;
    if timebreak(2) == 0
        error('Please Enter the Time in Seconds at which Treatment 2 was Initiated');
    end
end

if ~isempty(app.Treatment3EditField.Value)
    numcond = 3;
    timebreak(3)= app.EditField_3.Value * FPS;
    condnames{3} = app.Treatment3EditField.Value;
    if timebreak(3) == 0
        error('Please Enter the Time in Seconds at which Treatment 3 was Initiated');
    end
end


%% Standard Parameters

sigThres=.01; %threshold of signal
params.pad=0; %padding 
params.Fs= FPS; %sampling frequency (frames per second)
params.tapers= [2 3]; %[3 5]; %number of tapers (?)
params.trialave = 1; %do we trial average? 1 is yes.
params.err = [1 sigThres]; %error

bandpass = [0.05 FPS/2]; % [fqBandpass(1) fqBandpass(2) ];
params.fpass= bandpass;
%power spectrum


%% Now the figure

figure;
%first, plot and label the control series
seriesa = 1:timebreak(1)-1;
[SP,fP,errP]= mtspectrumc(datamat(chan,seriesa)', params); 

if app.CICheckBox.Value == 1
    SpectrumPlot(SP, fP, 'l',errP,'b',[2 1]);
else
    SpectrumPlot_NoErr(SP, fP, 'l','b',1)
end

a = annotation('textbox',[.7 .8 .1 .1],'String',['Baseline'],'EdgeColor','none');
a.Color = 'b';
a.FontSize = 16;

hold on;

% then, plot and label any treatments
colorwheel = {'r','k','m'};

for i = 1:numcond
    %If it's the end
    if i == numcond
        seriesb = timebreak(i):size(datamat,2);
    else
        seriesb = timebreak(i):(timebreak(i+1)-1);
    end
    
    [SM,fM,errM]= mtspectrumc(datamat(chan,seriesb)', params);
    
    if app.CICheckBox.Value == 1
        SpectrumPlot(SM, fM, 'l',errM,colorwheel{i},[2 1])
    else
        SpectrumPlot_NoErr(SM, fM, 'l',colorwheel{i},1)
    end
    
    boxheight = 0.8 - (i*.08);
    b = annotation('textbox',[.7 boxheight .1 .1],'String',[condnames(i)],'EdgeColor','none');
    b.Color = colorwheel{i};
    b.FontSize = 16;
    
end

set(gca,'fontsize', 16);
ylabel('Power Spec. Dens.');
xlabel('frequency(Hz)');
title('Power Spectrum');

% legend([{'Control'} {''} {''} {drugz}]);
