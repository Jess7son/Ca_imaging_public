function [] = ConnectivityPlot(app)
% FilePath = ('C:\Users\jess7\Documents\Grad_School\DHK_Labtime\ConfocalImages\180927-F-D10-rep2-NBQX_unf\Sphere02\');
% FileName = ('180927_JLS_Rt_8K_F_DIV09_cndFULL_SN02.mat');
% load([FilePath FileName]);
datamat = app.somaticF_DF(1:end-2,:);
numneurons = size(datamat,1);
fMetaData = app.fMetaData;
cstrength = app.cstrength; %coupling strength cutoff

FPS = fMetaData.frames/fMetaData.numsecs;
gauss = FPS/2; %gaussian filter width
specificfile = app.jpgimage;
xlims = [1 str2num(app.XdimEditField.Value)];
ylims = [1 str2num(app.YdimEditField.Value)];
cond = 1; %in case of concatanated files
somaticROICenters = app.somaticROICenters;

%% Don't touch below here

chan = 1:numneurons;   % select channels to include
%chan = [ 24 ]; % NOTE: you can also look at individual channels

figure() %'Renderer', 'painters', 'Position', [10 50 1000 600]);
h = gca;  hold on; 
%h.Color = [0 0 0]; 
h.XColor = 'none'; h.YColor = 'none';
h.YDir = 'reverse';
outerpos = h.OuterPosition;
ti = h.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3) - .03;
ax_height = outerpos(4) - ti(2) - ti(4) -.03;
h.Position = [left bottom ax_width ax_height];

imshow(specificfile, 'InitialMagnification', 100)
h.XLim = xlims; h.YLim = ylims; 

%% create the correlation matrix (necessary for later)

%create matrix of cell times
FiltSig = smoothdata(datamat(1:numneurons,:),2,'gaussian',gauss);

q = [];
for i = 1:size(FiltSig,1)
        q = [q; FiltSig(i,:)];
end

corr_matrix = corrcoef(q'); %create correlation coefficient matrix


%% Here, I'm using each cell's frequency to sort active from inactive cells

%calculate the frequency of each cell, and create a matrix of somatic
%centers

lincol = jet(101); c = []; d=[]; n2 = []; hundcolors = [];
%add the lines
for i=chan
    n1(i,:) = somaticROICenters{cond,i}.Centroid;
    
    for j = i+1:size(chan,2)
        %now compare every cell to every other cell, but only once.
      if (corr_matrix(i,j)>cstrength)
            n2 = somaticROICenters{cond,j}.Centroid;
            c = (corr_matrix(i,j)-cstrength)/(1-cstrength);
            hundcolors = round(c*100,0)+1;
            d = lincol(hundcolors,:);
            plot([n1(i,1) n2(1)],[n1(i,2) n2(2)],'LineWidth',.75,'Color',d)

      end
    end
end    

%go back and add the markers
for i=chan
    plot(n1(i,1),n1(i,2),'o','MarkerSize',10, ...
        'MarkerEdgeColor','r', 'MarkerFaceColor', 'r'); hold on;
end
