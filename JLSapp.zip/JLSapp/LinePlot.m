function [] = LinePlot(app)
%% Declare Variables 
somaticF_DF = app.somaticF_DF;
fMetaData = app.fMetaData;
inc = app.XincrementsEditField.Value; %increment for tic marks in X axis
thresh = app.threshholdEditField.Value; %threshold for defining "Active" cells
yLims = [app.yMinEditField.Value app.yMaxEditField.Value];

%% subtract background & get Df/f

sROIs = size(somaticF_DF,1)-2; %last 2 ROIs arent cells (neuropil & BG)
%calculate the frequency of each cell
activeCells=[]; bk_sub = [];

for i = 1:sROIs 
    bk_sub(i,:) = somaticF_DF(i,:);% - somaticF_DF(end,:);
end

Frames = fMetaData.frames; %usually 1500 or 3000
FPS = Frames/fMetaData.numsecs; %define Frames per second here
TimeVals = (FPS:FPS:Frames)/FPS; %getting seconds from frames
FrameVals = FPS:FPS:Frames; %For plotting
gauss = round(FPS/2);

%Now filter the signal with a gaussian filter of defined width
FiltSig = smoothdata(bk_sub,2,'gaussian',gauss);



for i = 1:size(FiltSig,1) %rough loop to find "active" cells
    if max(FiltSig(i,:))>thresh
        activeCells = [activeCells; FiltSig(i,:)];
    end
end
        

%% plot lines
figure('Renderer', 'painters', 'Position', [0 300 800 300]);
ax=gca; hold on;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1) + .08;
bottom = outerpos(2) + ti(2) + .19;
ax_width = outerpos(3) - ti(1) - ti(3) - .09;
ax_height = outerpos(4) - ti(2) - ti(4) - 0.25;
ax.Position = [left bottom ax_width ax_height];

ax.XTick = [FrameVals(inc:inc:end)]; ax.XTickLabel = [TimeVals(inc:inc:end)];
plot(activeCells', 'LineWidth', .75);
ax.FontSize = 20; 
xlabel('time(sec)'); ylabel('DeltaF / F');

if max (activeCells(:,:)) < yLims(2)
    ylim (yLims)
end
