function [] = CorrelationPlot(app)
%% Load in Variables
fMetaData = app.fMetaData;
somaticF_DF = app.somaticF_DF;
CorrThresh = app.MinSlider.Value;

FigTitle = [fMetaData.Date ' ' fMetaData.Size ' ' fMetaData.Sex ' DIV' fMetaData.Days_In_Vitro];
FPS = fMetaData.frames/fMetaData.numsecs;
gauss = FPS/2; %number of frames in gaussian filter

 %threshold for cellular correlation


%% ~~~~~~~~~~~ JESS ONLY BELOW HERE  ~~~~~~~~~~~
%create matrix of cell times
FiltSig = smoothdata(somaticF_DF(1:end-2,:),2,'gaussian',gauss);

q = [];
for i = 1:size(FiltSig,1)
        q = [q; FiltSig(i,:)];
end
%%
%r = q'; %flip the matrix
corr_matrix = corrcoef(q'); %create correlation coefficient matrix
% coher_matrix = mscohere(q');   
    
figure('Renderer', 'painters', 'Position', [10 50 675 575])
h = heatmap(corr_matrix); %plot as heatmap
h.Colormap = jet; %sets colorscheme
h.Title = FigTitle;
h.ColorLimits = [CorrThresh 1];
xlabel('Cell #'); ylabel('Cell #');


